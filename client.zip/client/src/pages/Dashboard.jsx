
export default function Dashboard() {
  return <h2>User Dashboard</h2>;
}
