
export default function Admin() {
  return <h2>Admin Panel</h2>;
}
